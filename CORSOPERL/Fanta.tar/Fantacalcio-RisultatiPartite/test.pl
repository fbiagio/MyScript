use Modern::Perl;
use Fantacalcio::Squadre;

open(my $fh,"<","./elencoSquadre.csv") || die "error opening file $!";
my %ElencoSquadre;
while (<$fh>){
	say $_;
	my @csv=split(/;/);
	$ElencoSquadre{"$_"} = Fantacalcio::Squadre->new(Presidente => $csv[0], Nome => $csv[1] , DisponibilitaEconomica => $csv[2] ); 
}


say "chiedo a ciascun oggetto di presentarsi";

for my $key (keys %ElencoSquadre){
#	say "Si presenti $ElencoSquadre{$key}:";
#	$ElencoSquadre{$key}->info();
}
close($fh);


